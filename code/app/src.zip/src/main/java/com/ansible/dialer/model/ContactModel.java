package com.ansible.dialer.model;

/**
 * Created by sundarsingh on 15/11/17.
 */

public class ContactModel {


    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone_no() {
        return phone_no;
    }

    public void setPhone_no(String phone_no) {
        this.phone_no = phone_no;
    }

    String phone_no;
}
