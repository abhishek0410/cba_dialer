package com.ansible.dialer.app;

import android.app.Application;
import android.support.multidex.MultiDex;

import com.ansible.dialer.R;

import uk.co.chrisjenx.calligraphy.CalligraphyConfig;

/**
 * Created by ${KS} on 24/11/17.
 */

public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/optus_heavy_bold.otf")
                .setFontAttrId(R.attr.fontPath)
                .build()
        );
        MultiDex.install(this);
    }
}
