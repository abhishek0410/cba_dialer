package com.ansible.dialer.activity;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.ansible.dialer.R;
import com.ansible.dialer.model.ContactModel;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SearchActivity extends Activity {

    @BindView(R.id.editText2)
    EditText editText2;
    @BindView(R.id.imageView3)
    ImageView imageView3;
    @BindView(R.id.rv_contact_list)
    RecyclerView rvContactList;
    @BindView(R.id.tv_no_search)
    TextView tvNoSearch;
    private String phoneNumber;
    private String nameContact;
    private ContactAdapter contactAdapter;
    List<ContactModel> contactModelsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(editText2.getWindowToken(), 0);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this);
        rvContactList.setLayoutManager(mLayoutManager);
        rvContactList.setItemAnimator(new DefaultItemAnimator());
        getNumber(this.getContentResolver());
        editText2.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                // When user changed the Text

            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
                                          int arg3) {
                // TODO Auto-generated method stub

            }

            @Override
            public void afterTextChanged(Editable arg0) {
                // TODO Auto-generated method stub
                filter(arg0.toString());
            }
        });
    }

    private void filter(String text) {
        //new array list that will hold the filtered data
        ArrayList<ContactModel> filterdNames = new ArrayList<>();

        //looping through existing elements
        for (ContactModel filterdName : contactModelsList) {
            //if the existing elements contains the search input
            if (filterdName.getName().toLowerCase().contains(text.toLowerCase())) {
                //adding the element to filtered list
                filterdNames.add(filterdName);
            }
        }

        //calling a method of the adapter class and passing the filtered list
        if (filterdNames.size() > 0) {
            contactAdapter.filterList(filterdNames);
            tvNoSearch.setVisibility(View.GONE);
        } else {
            tvNoSearch.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(SearchActivity.this, DiallerViewActivity.class));
        finish();

    }


    private void getNumber(ContentResolver crr) {
        ContentResolver cr = getContentResolver(); //Activity/Application android.content.Context
        Cursor cursor = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
        ArrayList<String> alContacts = new ArrayList<String>();
        if (cursor.moveToFirst()) {
            do {
                String id = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));

                if (Integer.parseInt(cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                    Cursor pCur = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", new String[]{id}, null);
                    while (pCur.moveToNext()) {
                        ContactModel contactModel = new ContactModel();
                        String contactNumber = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                        String contactName = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                        alContacts.add(contactNumber);
                        contactModel.setName(contactName);
                        contactModel.setPhone_no(contactNumber);
                        contactModelsList.add(contactModel);
                        break;
                    }
                    pCur.close();
                }

            } while (cursor.moveToNext());
        }

        System.out.print("contactModelsList" + contactModelsList);
        if (contactModelsList != null && contactModelsList.size() > 0) {
            contactAdapter = new ContactAdapter(this, contactModelsList);
            rvContactList.setAdapter(contactAdapter);
        }
    }


}
