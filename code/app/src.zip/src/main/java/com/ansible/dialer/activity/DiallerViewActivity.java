package com.ansible.dialer.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.support.v4.app.ActivityCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ansible.dialer.AppUtils.FeedContextMenu;
import com.ansible.dialer.AppUtils.FeedContextMenuManager;
import com.ansible.dialer.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;


public class DiallerViewActivity extends Activity implements FeedContextMenu.OnFeedContextMenuItemClickListener {
    public static EditText etPhoneNo;
    @BindView(R.id.grid_view)
    GridView gridView;
    @BindView(R.id.iv_clear_no)
    ImageView ivClearNo;
    @BindView(R.id.ll_call)
    LinearLayout llCall;
    @BindView(R.id.iv_contact)
    ImageView ivContact;
    @BindView(R.id.tv_emergency)
    TextView tvEmergency;
    @BindView(R.id.view)
    View view;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialler_detail);
        ButterKnife.bind(this);
        Intent intent = getIntent();
        final Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        etPhoneNo = (EditText) findViewById(R.id.et_phone_no);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(etPhoneNo.getWindowToken(), 0);
        gridView.setAdapter(new DiallerAdapter(this));
        etPhoneNo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (etPhoneNo.length() == 0) {
                    ivClearNo.setVisibility(View.INVISIBLE);
                    etPhoneNo.setEnabled(false);
                } else {
                    etPhoneNo.requestFocus();
                    etPhoneNo.setEnabled(true);
                    ivClearNo.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (etPhoneNo.length() == 0) {
                    ivClearNo.setVisibility(View.INVISIBLE);
                    etPhoneNo.setEnabled(false);
                } else {
                    etPhoneNo.requestFocus();
                    etPhoneNo.setEnabled(true);
                    ivClearNo.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (etPhoneNo.length() == 0) {
                    ivClearNo.setVisibility(View.INVISIBLE);
                    etPhoneNo.setEnabled(false);
                } else {
                    etPhoneNo.requestFocus();
                    etPhoneNo.setEnabled(true);
                    ivClearNo.setVisibility(View.VISIBLE);
                }
            }
        });
        if ((intent.getStringExtra("Phone") != null)) {
            etPhoneNo.setText(intent.getStringExtra("Phone"));
            String phoneNo = intent.getStringExtra("Phone");
            for (int i = 0; i < phoneNo.length(); i++) {
                DiallerAdapter.stringList.add(String.valueOf(phoneNo.charAt(i)));
            }
        }
        ivContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onContactClick(view);
                view.setVisibility(View.VISIBLE);
            }
        });
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FeedContextMenuManager.getInstance(getApplicationContext()).hideContextMenu();
                view.setVisibility(View.GONE);
            }
        });
        etPhoneNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(etPhoneNo.getWindowToken(), 0);
            }
        });
        ivClearNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (DiallerAdapter.stringList != null && DiallerAdapter.stringList.size() > 0) {
                    DiallerAdapter.stringList.remove(DiallerAdapter.stringList.size() - 1);
                    String test = "";
                    for (int i = 0; i < DiallerAdapter.stringList.size(); i++) {
                        test = test + DiallerAdapter.stringList.get(i);
                    }
                    etPhoneNo.setText(test);
                }
            }
        });
        ivClearNo.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                vibrator.vibrate(100);
                DiallerAdapter.stringList.clear();
                etPhoneNo.setText("");
                return false;
            }
        });
        llCall.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            @Override
            public void onClick(View view) {
                if (DiallerAdapter.stringList != null && DiallerAdapter.stringList.size() > 0) {
                    Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + "0279228000,,062705%23,," + etPhoneNo.getText().toString()));
//                    Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + etPhoneNo.getText().toString()));
                    if (ActivityCompat.checkSelfPermission(DiallerViewActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    }
                    startActivity(intent);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            finish();
                        }
                    }, 2000);
                } else {
                    Toast.makeText(DiallerViewActivity.this, "Please enter no", Toast.LENGTH_SHORT).show();
                }
            }
        });
        tvEmergency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(DiallerViewActivity.this, "Coming soon", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void onContactClick(View view) {
        FeedContextMenuManager.getInstance(this).toggleContextMenuFromView(view, 0, this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (FeedContextMenuManager.getInstance(this).isShowing()) {
            view.setVisibility(View.GONE);
            FeedContextMenuManager.getInstance(this).hideContextMenu();
        }
    }

    @Override
    public void onServerContacts(int feedItem) {
        view.setVisibility(View.GONE);
        FeedContextMenuManager.getInstance(this).hideContextMenu();
        startActivity(new Intent(DiallerViewActivity.this, SearchActivity.class));
        finish();
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
