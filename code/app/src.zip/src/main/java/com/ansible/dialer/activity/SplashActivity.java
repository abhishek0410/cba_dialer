package com.ansible.dialer.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.Toast;

import com.ansible.dialer.R;
import com.tbruyelle.rxpermissions2.RxPermissions;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class SplashActivity extends Activity {
    RxPermissions rxPermissions;
    private Button mBtnBranch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        rxPermissions = new RxPermissions(this);
        if (Build.VERSION.SDK_INT >= 23) {
            permission();
        } else {
            startMainActivity();
        }


    }

    private void permission() {
        rxPermissions
                .request(android.Manifest.permission.READ_CONTACTS, android.Manifest.permission.CALL_PHONE)
                .subscribe(granted -> {
                    if (granted) {
                        startMainActivity();
                    } else {
                        permission();
                        Toast.makeText(SplashActivity.this, "Grant permission frist.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void startMainActivity() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // This method will be executed once the timer is over
                // Start your app main activity
                startActivity(new Intent(SplashActivity.this, DiallerViewActivity.class));
                finish();
            }
        }, 3000);

    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
