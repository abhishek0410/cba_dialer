package com.ansible.dialer.activity;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.ansible.dialer.R;
import com.ansible.dialer.model.ContactModel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.MyViewHolder> {
    LayoutInflater inflater;
    Activity mContext;
    List<String> phoneNoList = new ArrayList<>();
    List<String> nameList = new ArrayList<>();
    List<ContactModel> contactModels = new ArrayList<>();

    public ContactAdapter(Activity activity,  List<ContactModel> contactModelsList) {

        this.mContext = activity;
        this.contactModels = contactModelsList;
        Collections.sort(contactModels, new Comparator<ContactModel>() {
            public int compare(ContactModel obj1, ContactModel obj2) {
                // ## Ascending order
                return obj1.getName().compareToIgnoreCase(obj2.getName()); // To compare string values
                // return Integer.valueOf(obj1.empId).compareTo(obj2.empId); // To compare integer values

                // ## Descending order
                // return obj2.firstName.compareToIgnoreCase(obj1.firstName); // To compare string values
                // return Integer.valueOf(obj2.empId).compareTo(obj1.empId); // To compare integer values
            }
        });
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        MyViewHolder viewHolder = null;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View rightView = inflater.inflate(R.layout.search_list_item, parent, false);
        viewHolder = new MyViewHolder(rightView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {

//        holder.mTvName.setText(nameList.get(position).toString());
        try {
            if (contactModels.get(position).getName() != null) {
                holder.mTvName.setText(contactModels.get(position).getName());
            }
            if (contactModels.get(position).getPhone_no() != null) {
                holder.mTvNo.setText(String.valueOf(contactModels.get(position).getPhone_no()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        holder.llItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mContext.startActivity(new Intent(mContext, DiallerViewActivity.class).putExtra("Phone", contactModels.get(position).getPhone_no()));
                mContext.finish();
            }
        });


    }

    @Override
    public int getItemCount() {
        return contactModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView mTvName, mTvNo;
        private LinearLayout llItem;

        public MyViewHolder(View view) {
            super(view);
            mTvName = (TextView) view.findViewById(R.id.txt_name);
            mTvNo = (TextView) view.findViewById(R.id.number);
            llItem = (LinearLayout) view.findViewById(R.id.ll_item);

        }
    }

    public void filterList(ArrayList<ContactModel> filterdNames) {
        this.contactModels = filterdNames;
        notifyDataSetChanged();
    }
}

